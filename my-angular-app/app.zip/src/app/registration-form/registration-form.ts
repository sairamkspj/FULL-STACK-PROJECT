import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-registration-form',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './registration-form.html',
  styleUrls: ['./registration-from.css']
})
export class RegistrationFormComponent  {
  user = {
    name: '',
    age: ''
  };

  onSubmit() {
    console.log('Form Submitted!', this.user);
    alert(`User Registered: ${this.user.name}, Age: ${this.user.age}`);
  }
}
