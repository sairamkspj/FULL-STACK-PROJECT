import { Routes } from '@angular/router';
import { RegistrationFormComponent } from './registration-form/registration-form';

export const routes: Routes = [
  { path: '', component: RegistrationFormComponent }
];
